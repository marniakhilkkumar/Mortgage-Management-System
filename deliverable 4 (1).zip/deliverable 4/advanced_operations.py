import mysql.connector

def olap_operation(connection, table_name):
    try:
        cursor = connection.cursor()

        cursor.execute(f"SHOW COLUMNS FROM {table_name}")
        columns = [column[0] for column in cursor.fetchall()]
        print("\nAvailable Columns:\n")
        for column in columns:
            print(column)

        group_by_column = input("\nEnter the column to group by: ")
        aggregate_column = input("Enter the column to aggregate: ")
        aggregation_function = input("Enter the aggregation function (e.g., SUM, AVG, MAX, MIN): ")

        if group_by_column not in columns:
            print("\nInvalid group_by_column name.")
            return
        
        if aggregate_column not in columns:
            print("\nInvalid aggregate_column name.")
            return

        query = f"SELECT {group_by_column}, {aggregation_function}({aggregate_column}) AS aggregate_result FROM {table_name} GROUP BY {group_by_column}"
        
        cursor.execute(query)
        records = cursor.fetchall()

        print(f"\n ######### OLAP Result for groupBy {group_by_column} and {aggregation_function} function is: #############\n")
        if records:
            for index, record in enumerate(records):
                formatted_record = ", ".join(f"{key}: {value}" for key, value in zip([group_by_column, "aggregate_result"], record))
                print(f"Record {index + 1}: {{{formatted_record}}}")

    except mysql.connector.Error as error:
        print("An error occurred:", error)

    finally:
        cursor.close()

def sort_operation(connection, table_name):
    try:
        cursor = connection.cursor()

        cursor.execute(f"SHOW COLUMNS FROM {table_name}")
        columns = [column[0] for column in cursor.fetchall()]
        print("\nAvailable Columns:\n")
        for column in columns:
            print(column)

        sort_column = input("\nEnter the column to sort by: ")
        sort_order = input("Enter the sort order (ASC or DESC): ").upper()

        if sort_column not in columns:
                print("Invalid column name.")
                return
        
        if sort_order not in ['ASC', 'DESC']:
            print("Invalid sort order.")
            return

        query = f"SELECT * FROM {table_name} ORDER BY {sort_column} {sort_order}"
        
        cursor.execute(query)
        records = cursor.fetchall()

        print("\n ######Sorted Result: ########\n")
        if records:
            for index, record in enumerate(records):
                formatted_record = ", ".join(f"{key}: {value}" for key, value in zip(columns, record))
                print(f"Record {index + 1}: {{{formatted_record}}}")

    except mysql.connector.Error as error:
        print("An error occurred:", error)

    finally:
        cursor.close()

def rank_operation(connection, table_name):
    try:
        with connection.cursor() as cursor:
            cursor.execute("SHOW COLUMNS FROM {}".format(table_name))
            columns = [column[0] for column in cursor.fetchall()]
            print("\nAvailable Columns:\n")
            for column in columns:
                print(column)

            rank_column = input("Enter the column to rank by: ")

            if rank_column not in columns:
                print("Invalid column name.")
                return

            query = f"SELECT *, RANK() OVER (ORDER BY {rank_column} DESC) AS `Rank` FROM {table_name};"
            cursor.execute(query)
            records = cursor.fetchall()

            print("\n #####Rank Result: ######\n")
            if records:
                for index, record in enumerate(records):
                    formatted_record = ", ".join(f"{key}: {value}" for key, value in zip(columns + ['Rank'], record))
                    print(f"Record {index + 1}: {{{formatted_record}}}")

    except mysql.connector.Error as error:
        print("An error occurred:", error)

def window_operation(connection, table_name):
    try:
        cursor = connection.cursor()

        cursor.execute(f"SHOW COLUMNS FROM {table_name}")
        columns = [column[0] for column in cursor.fetchall()]
        print("\nAvailable Columns:\n")
        for column in columns:
            print(column)

        window_size = input("Enter the window size: ")
        window_column = input("Enter the column to apply window function: ")

        if window_column not in columns:
                print("Invalid column name.")
                return

        query = f"SELECT *, AVG({window_column}) OVER (ORDER BY {window_column} DESC ROWS BETWEEN {window_size} PRECEDING AND {window_size} FOLLOWING) AS Moving_Average FROM {table_name}"
        
        cursor.execute(query)
        records = cursor.fetchall()

        print("\n #######Window Function Result: ###### \n")
        if records:
            for index, record in enumerate(records):
                formatted_record = ", ".join(f"{key}: {value}" for key, value in zip(columns +['Moving_Average'], record))
                print(f"Record {index + 1}: {{{formatted_record}}}")

    except mysql.connector.Error as error:
        print("An error occurred:", error)

    finally:
        cursor.close()

def get_last_payment(cursor, customer_id):
    query = f"SELECT MAX(PaymentDate) FROM Payments WHERE CustomerID = {customer_id}"
    cursor.execute(query)
    last_payment = cursor.fetchone()[0]
    return last_payment

def get_highest_payment(cursor, customer_id):
    query = f"SELECT MAX(Amount) FROM Payments WHERE CustomerID = {customer_id}"
    cursor.execute(query)
    highest_payment = cursor.fetchone()[0]
    return highest_payment

def get_loan_remaining(cursor, customer_id):
    query = f"""
        SELECT 
            SUM(l.Amount) + SUM(l.Amount * l.InterestRate * l.Duration / 12 / 100) - COALESCE(SUM(p.Amount), 0) AS remaining_loan
        FROM 
            Loan l 
        LEFT JOIN 
            Payments p ON l.LoanID = p.LoanID 
        WHERE 
            l.CustomerID = {customer_id}
    """
    cursor.execute(query)
    remaining_loan = cursor.fetchone()[0]  # Fetching the remaining_loan from the result set
    return remaining_loan

def get_last_paid_dates(cursor, customer_id):
    query = f"SELECT DISTINCT PaymentDate FROM Payments WHERE CustomerID = {customer_id} ORDER BY PaymentDate DESC LIMIT 3"
    cursor.execute(query)
    last_paid_dates = [row[0] for row in cursor.fetchall()]
    return last_paid_dates

def customer_payment_info(connection, customer_id):
    try:
        cursor = connection.cursor()

        # Fetch customer details
        cursor.execute(f"SELECT * FROM Customers WHERE CustomerID = {customer_id}")
        customer_details = cursor.fetchone()

        if customer_details:
            print("\n ======= Customer Details =======\n")
            print(f"Customer ID: {customer_details[0]}")
            print(f"First Name: {customer_details[1]}")
            print(f"Last Name: {customer_details[2]}")
            print(f"Address: {customer_details[3]}")
            print(f"Email: {customer_details[4]}")
            print(f"Phone: {customer_details[5]}")

            # Fetch payment information
            last_payment = get_last_payment(cursor, customer_id)
            highest_payment = get_highest_payment(cursor, customer_id)
            remaining_loan = get_loan_remaining(cursor, customer_id)
            last_paid_dates = get_last_paid_dates(cursor, customer_id)

            print("\n ======= Customer Payment Information =======\n")
            print(f"Last Payment Date: {last_payment}")
            print(f"Highest Payment Amount: {highest_payment:.2f}")
            print(f"Remaining Loan Amount: {remaining_loan:.2f}")
            print("Last Three Paid Dates:")
            for date in last_paid_dates:
                print(date)

        else:
            print(f"Customer with ID {customer_id} not found.")

    except mysql.connector.Error as error:
        print("An error occurred:", error)

    finally:
        cursor.close()