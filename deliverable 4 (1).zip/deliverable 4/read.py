import mysql.connector
def read_records(connection, table):
    try:
        cursor = connection.cursor(dictionary=True)
        select_query = f"SELECT * FROM {table}"
        cursor.execute(select_query)
        records = cursor.fetchall()
        if records:
            print("\nRecords:")
            for index, record in enumerate(records):
                print(f"Record {index + 1}: {', '.join(f'{key}: {value}' for key, value in record.items())}")
        else:
            print("No records found in the table.")
            
    except mysql.connector.Error as error:
        print("Error:", error)