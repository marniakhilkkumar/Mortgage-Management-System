from advanced_operations import customer_payment_info, olap_operation, rank_operation, sort_operation, window_operation
from db_connection import connect_to_database, close_database_connection, get_primary_key
from create import create_record
from read import read_records
from update import update_record
from delete import delete_record

def list_tables(connection):
    cursor = connection.cursor()
    cursor.execute("SHOW TABLES")
    tables = [table[0] for table in cursor.fetchall()]
    return tables

def select_table():
    while True:
        print("\n===== Select a Table to perform operations  =====")
        tables = list_tables(connection)
        print("\n\nAvailable Tables:\n")
        for index, table in enumerate(tables):
            print(f"{index + 1}. {table}")

        table_choice = input("\nPlease select the table you wish to work with: ")
        try:
            table_index = int(table_choice) - 1
            if 0 <= table_index < len(tables):
                return tables[table_index]
            else:
                print("Invalid table choice. Please select a valid table.")
        except ValueError:
            print("Invalid input. Please enter a valid number.")

def want_to_Continue():
        print("===================================================\n")
        value = input(f"Do you want to perform more operations(Y/N):")
        if value.lower() == "y":
            return True
        return False

def perform_operation(table_name,primary_key):

    if primary_key is None:
        print(f"Table {table_name} does not have a primary key defined.")
        return
    
    while True:
        print(f"\nTable: {table_name}")
        print("\n ==================  CRUD Operations Menu:  ================\n")
        print(f"1. Create (Insert) Record on {table_name} Table")
        print(f"2. Read (Retrieve) Records on {table_name} Table")
        print(f"3. Update Record on {table_name} Table")
        print(f"4. Delete Record from {table_name} Table")
        print("5. Back to Main Menu\n")

        operation = input("Select an operation to perform: ")
        if operation == '5':
            break
        elif operation == '1':
            create_record(connection, table_name)
        elif operation == '2':
            read_records(connection, table_name)
        elif operation == '3':
            update_record(connection, table_name, primary_key)
        elif operation == '4':
            delete_record(connection, table_name, primary_key)
        else:
            print("Invalid operation. Please select again from the list of operations.")

        if want_to_Continue() == False:
                break

def advanced_operations_menu(table_name,primary_key):

    if primary_key is None:
        print(f"Table {table_name} does not have a primary key defined.")
        return
    
    while True:
        print(f"\nTable: {table_name}")
        print("\n ==============  Advanced operations menu: ============= \n")
        print("1. OLAP")
        print("2. Sort()")
        print("3. Rank()")
        print("4. Window Operation")
        if table_name.lower() == "customers":
            print("5. Show Customer Payment related Info")
            print("6. Back to Main Menu \n")
        else:
            print("5. Back to Main Menu \n")

        operation = input("Select an operation to perform: ")
        if operation == '5' and table_name != "Customers":
            break
        elif operation == '6':
            break
        elif operation == '1':
            olap_operation(connection, table_name)
        elif operation == '2':
            sort_operation(connection, table_name)
        elif operation == '3':
            rank_operation(connection, table_name)
        elif operation == '4':
            window_operation(connection, table_name)
        elif operation == '5' and table_name == "Customers":
            customerID = input(f"\nEnter the Customer Id you want to find the Payment Info:")
            customer_payment_info(connection, customerID)
        else:
            print("\nInvalid operation. Please select again from the list of operations.")

        if want_to_Continue() == False:
                break

def main():
    while True:
        print("\n============= Mortgage Management System ============")
        table_name = select_table()
        primary_key = get_primary_key(connection, table_name)

        print("\n ============ OPERATIONS =============")
        print("\n1. CRUD Operations - (Read, Create, Delete, Update)")
        print("2. Advanced Operations")
        print("3. Exit\n")
        choice = input("Enter your choice: ")

        if choice == "1":
            perform_operation(table_name,primary_key)
        
        elif choice == "2":
            advanced_operations_menu(table_name,primary_key)
        
        elif choice == "3":
            print("Exiting the application.")
            break
        
        else:
            print("Invalid choice. Please select a valid option.")

if __name__ == "__main__":
    try:
        with connect_to_database() as connection:
            if connection:
                main()
                close_database_connection(connection)
    except Exception as e:
        print("An error occurred:", e)