import mysql.connector

def connect_to_database():
    try:
        connection = mysql.connector.connect(
            host="127.0.0.1",
            user="root",
            password="Tryhard1!",
            database="MortgageManagementSystem"
        )
        if connection.is_connected():
            print("Connected to MySQL database")
            return connection
        else:
            print("Failed to connect to the database")

    except mysql.connector.Error as error:
        print("Error: ", error)

    return None

def close_database_connection(connection):
    if connection:
        connection.close()
        print("Connection closed")

def get_primary_key(connection, table_name):
    try:
        cursor = connection.cursor()
        cursor.execute(f"SHOW KEYS FROM {table_name} WHERE Key_name = 'PRIMARY'")
        primary_key = cursor.fetchone()
        if primary_key:
            return primary_key[4]
        return None
    except mysql.connector.Error as error:
        print("Error:", error)
        return None
