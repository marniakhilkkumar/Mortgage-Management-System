import mysql.connector
from db_connection import connect_to_database, close_database_connection


def update_record(connection, table_name, primary_key):
    try:
        cursor = connection.cursor()

        primary_key_value = input(f"Enter the {primary_key} of the record to update: ")
        data_input = input(f"Enter the new values of the record in ({', '.join(get_table_columns(connection, table_name))}) format: ")
        values = data_input.split(',')
        if len(values) != len(get_table_columns(connection, table_name)):
            print("Invalid input. Please provide values for all columns.")
        else:
            data = {column: value for column, value in zip(get_table_columns(connection, table_name), values)}

        placeholders = ', '.join([f"{col} = %s" for col in data])
        update_query = f"UPDATE {table_name} SET {placeholders} WHERE {primary_key} = %s"

        record_data = tuple(data.values()) + (primary_key_value,)

        cursor.execute(update_query, record_data)
        connection.commit()

        if cursor.rowcount > 0:
            print(f"Record with {primary_key} {primary_key_value} updated successfully")
        else:
            print(f"No record with {primary_key} {primary_key_value} found for update")

    except mysql.connector.Error as error:
        print("Error:", error)
        connection.rollback()

def get_table_columns(connection, table_name):
    cursor = connection.cursor()
    cursor.execute(f"SHOW COLUMNS FROM {table_name}")
    columns = [column[0] for column in cursor.fetchall()]
    return columns