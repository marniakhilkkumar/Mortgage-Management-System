import mysql.connector



def create_record(connection, table_name):
    try:
        data_input = input(f"Enter the values of the record in ({', '.join(get_table_columns(connection, table_name))}) format: ")
        values = data_input.split(',')
        if len(values) != len(get_table_columns(connection, table_name)):
            print("Invalid input. Please provide values for all columns.")
        else:
            data = {column: value for column, value in zip(get_table_columns(connection, table_name), values)}

        cursor = connection.cursor()
        columns = ', '.join(data.keys())
        placeholders = ', '.join(['%s' for _ in data])
        insert_query = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})"
        record_data = tuple(data.values())
        cursor.execute(insert_query, record_data)
        connection.commit()
        print("Record inserted successfully")
    except mysql.connector.Error as error:
        print("Error:", error)
        connection.rollback()

def get_table_columns(connection, table_name):
    cursor = connection.cursor()
    cursor.execute(f"SHOW COLUMNS FROM {table_name}")
    columns = [column[0] for column in cursor.fetchall()]
    return columns